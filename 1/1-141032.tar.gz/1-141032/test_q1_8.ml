#use "q1_8.ml";;

appendr [1;2;3] [4;5;6];;

appendl [1;2;3] [4;5;6];;

lastr [1;2;3];;          

lastl [1;2;3];;

mapr (fun x -> x + 1) [1;2;3];; 

mapl (fun x -> x + 1) [1;2;3];;
