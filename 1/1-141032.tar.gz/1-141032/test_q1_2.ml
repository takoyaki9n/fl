#use "q1_2.ml";;
  
List.map (fun n -> fib1 n) [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];;
    
List.map (fun n -> fib2 n) [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];;
      
