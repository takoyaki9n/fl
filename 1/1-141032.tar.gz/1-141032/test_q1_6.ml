#use "q1_6.ml";;

append [1;2;3] [4;5;6];;

last [1;2;3];;

map (fun x -> x + 1) [1;2;3];;
