#use "q1_1.ml";;

List.map (fun n -> sum_to n) [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];; 

List.map (fun n -> is_prime n) [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];;

gcd 105 135;;
