#use "q1_7.ml";;

reverse [1;2;3];;
