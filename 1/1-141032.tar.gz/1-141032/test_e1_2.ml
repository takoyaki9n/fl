#use "e1_2.ml";;

fold_rightl ( - ) [1;2;3;4;5] 0;;

fold_leftr ( - ) 0 [1;2;3;4;5];; 
