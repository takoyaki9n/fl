#use "q1_5.ml";;

fold_right ( - ) [1;2;3;4;5] 0;;

fold_left ( - ) 0 [1;2;3;4;5];; 
