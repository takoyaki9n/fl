#use "e1_1.ml";;

reverser [1;2;3];;
