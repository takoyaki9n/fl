#use "q1_9.ml";;

perm [1;2;3];;
